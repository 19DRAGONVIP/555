import xbmc
import xbmcaddon
import xbmcgui,xbmcvfs
import xbmcplugin
from shutil import copyfile
import sys

try:  # Python 3
    from urllib.parse import parse_qsl
except ImportError:  # Python 2
    from urlparse import parse_qsl
import os,re
from resources.libs.common.config import CONFIG
from resources.libs.common import logging
from resources.libs.common import tools
from resources.libs.gui import menu
ADDON = xbmcaddon.Addon()
advanced_settings_mode = 'advanced_settings'
addon_installer_mode = 'addons'
TMDB_NEW_API ='aG9qaw=='#line:57
HOME             = xbmcvfs.translatePath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
def decode (OOOO0OOOO0O0000O0 ,O00O0OOO0O0OO0O0O ):#line:1872
    import logging
    import base64 #line:1873
    O0O000OO0O0O00OO0 =[]#line:1874
    if (len (OOOO0OOOO0O0000O0 ))!=4 :#line:1876
     return 10 #line:1877
    O00O0OOO0O0OO0O0O =base64 .b64decode (O00O0OOO0O0OO0O0O ).decode('utf-8')#line:1878
    logging.warning(O00O0OOO0O0OO0O0O)
    for OO00OO0O00OO0O0O0 in range (len (O00O0OOO0O0OO0O0O )):#line:1880
        O00OO0OO00O0O00OO =OOOO0OOOO0O0000O0 [OO00OO0O00OO0O0O0 %len (OOOO0OOOO0O0000O0 )]#line:1881
        O0OO0O00OO00OOO00 =chr ((256 +ord (O00O0OOO0O0OO0O0O [OO00OO0O00OO0O0O0 ])-ord (O00OO0OO00O0O00OO ))%256 )#line:1882
        O0O000OO0O0O00OO0 .append (O0OO0O00OO00OOO00 )#line:1883
    return "".join (O0O000OO0O0O00OO0 )#line:1884
def disply_hwr ():#line:1921
   O0O0OO0OO0OO0000O =tmdb_list (TMDB_NEW_API )#line:1922
   OOO0O00OOOOOOO0OO =str ((getHwAddr ('eth0'))*O0O0OO0OO0OO0000O )#line:1923
   OOO000OO000OO0OOO =(OOO0O00OOOOOOO0OO [1 ]+OOO0O00OOOOOOO0OO [2 ]+OOO0O00OOOOOOO0OO [5 ]+OOO0O00OOOOOOO0OO [7 ])#line:1927
   O00OOOO0O0OO0OOO0 =(ADDON .getSetting ("action"))#line:1928
   wiz .setS ('action',str (OOO000OO000OO0OOO ))#line:1930
def disply_hwr2 ():#line:1931
   O0OO0OO00OOOOO00O =tmdb_list (TMDB_NEW_API )#line:1932
   OO000O0O00OOOOO0O =str ((getHwAddr ('eth0'))*O0OO0OO00OOOOO00O )#line:1933
   OO00O0O0O0OOOO000 =(OO000O0O00OOOOO0O [1 ]+OO000O0O00OOOOO0O [2 ]+OO000O0O00OOOOO0O [5 ]+OO000O0O00OOOOO0O [7 ])#line:1937
   OOOO00OO00O00O000 =(ADDON .getSetting ("action"))#line:1938
   xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO00O0O0O0OOOO000 )#line:1941
def getHwAddr (OO0OO000O0O0OOO00 ):#line:1943
   import subprocess ,time #line:1944
   OO0OO0OOOO000000O ='windows'#line:1945
   if xbmc .getCondVisibility ('system.platform.android'):#line:1946
       OO0OO0OOOO000000O ='android'#line:1947
   if xbmc .getCondVisibility ('system.platform.android'):#line:1948
     O0OOO000O000O0O0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1949
     O0O00OO000O0OOOOO =re .compile ('link/ether (.+?) brd').findall (str (O0OOO000O000O0O0O ))#line:1951
     OO0000OO00O00O000 =0 #line:1952
     for OO000OO00O000O0O0 in O0O00OO000O0OOOOO :#line:1953
      if O0O00OO000O0OOOOO !='00:00:00:00:00:00':#line:1954
          OOO00OOO0OOO0000O =OO000OO00O000O0O0 #line:1955
          OO0000OO00O00O000 =OO0000OO00O00O000 +int (OOO00OOO0OOO0000O .replace (':',''),16 )#line:1956
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1958
       O0O0O0O0000O00OO0 =0 #line:1959
       OO0000OO00O00O000 =0 #line:1960
       OO0OO0OOOOOOOO0OO =[]#line:1961
       OOOO0OO0O00O0OO0O =os .popen ("getmac").read ()#line:1962
       OOOO0OO0O00O0OO0O =OOOO0OO0O00O0OO0O .split ("\n")#line:1963
       for O00O0OOOOO0OO00OO in OOOO0OO0O00O0OO0O :#line:1965
            OOO000O0OOO000OOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00O0OOOOO0OO00OO ,re .I )#line:1966
            if OOO000O0OOO000OOO :#line:1967
                O0O00OO000O0OOOOO =OOO000O0OOO000OOO .group ().replace ('-',':')#line:1968
                OO0OO0OOOOOOOO0OO .append (O0O00OO000O0OOOOO )#line:1969
                OO0000OO00O00O000 =OO0000OO00O00O000 +int (O0O00OO000O0OOOOO .replace (':',''),16 )#line:1972
   else :#line:1974
       O0O0O0O0000O00OO0 =0 #line:1975
       OO0000OO00O00O000 =0 #line:1976
       while (1 ):#line:1977
         OOO00OOO0OOO0000O =xbmc .getInfoLabel ("network.macaddress")#line:1978
         logging .warning (OOO00OOO0OOO0000O )#line:1979
         if OOO00OOO0OOO0000O !="Busy"and OOO00OOO0OOO0000O !=' עסוק':#line:1980
            break #line:1982
         else :#line:1983
           O0O0O0O0000O00OO0 =O0O0O0O0000O00OO0 +1 #line:1984
           time .sleep (1 )#line:1985
           if O0O0O0O0000O00OO0 >30 :#line:1986
            break #line:1987
       OO0000OO00O00O000 =OO0000OO00O00O000 +int (OOO00OOO0OOO0000O .replace (':',''),16 )#line:1988
       logging .warning ('n:'+str (OO0000OO00O00O000 ))#line:1989
   return OO0000OO00O00O000 #line:1990
def u_list (O0O00OOOOOO00O0O0 ):#line:1892
    import logging
    from math import sqrt #line:1894
    O00OOO0OO000O000O =tmdb_list (TMDB_NEW_API )#line:1895
    O00O0OOOOOO000OO0 =str ((getHwAddr ('eth0'))*O00OOO0OO000O000O )#line:1897
    O00000OO0OO00O0O0 =int (O00O0OOOOOO000OO0 [1 ]+O00O0OOOOOO000OO0 [2 ]+O00O0OOOOOO000OO0 [5 ]+O00O0OOOOOO000OO0 [7 ])#line:1899
    OO0OO0OO00O000O0O =(ADDON .getSetting ("pass"))#line:1901
    OOOOOOOO0O0O0OO0O =(str (round (sqrt ((O00000OO0OO00O0O0 *860 )+20 )+20 ,4 ))[-4 :]).replace ('.','')#line:1906
    if '.'in OOOOOOOO0O0O0OO0O :#line:1907
     OOOOOOOO0O0O0OO0O =(str (round (sqrt ((O00000OO0OO00O0O0 *860 )+20 )+20 ,4 ))[-5 :]).replace ('.','')#line:1908
    
    if OO0OO0OO00O000O0O ==OOOOOOOO0O0O0OO0O :#line:1910
        OOOOOO0O0OOOOO0O0 =O0O00OOOOOO00O0O0 #line:1912
       
        return OOOOOO0O0OOOOO0O0,O00000OO0OO00O0O0 #line:1913
    else :#line:1914
       OOOOOO0O0OOOOO0O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1916
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1917
    
    return 'aa',O00000OO0OO00O0O0#line:1919
def tmdb_list (OOO00OO000OOOOO00 ):#line:1885
    O00OOO0O00O000O0O =decode ("7643",OOO00OO000OOOOO00 )#line:1888
    return int (O00OOO0O00O000O0O )#line:1891
def backtokodi():
    if os.path.exists(os.path.join(ADDONS, 'skin.xenon18')):

            src=os.path.join(xbmcvfs.translatePath("special://home/addons/plugin.program.Dragon-Wizard19"),"resources","guisettings.xml")
            dst=os.path.join(xbmcvfs.translatePath("special://home/"),"userdata","guisettings.xml")
            copyfile(src,dst)
            os._exit(1)
    else:
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Dragon', 'הבילד לא מותקן.')))

class Router:
    def __init__(self):
        self.route = None
        self.params = {}
        tools.ensure_folders()

    def _log_params(self, paramstring):
        _url = sys.argv[0]

        self.params = dict(parse_qsl(paramstring))

        logstring = '{0}: '.format(_url)
        for param in self.params:
            logstring += '[ {0}: {1} ] '.format(param, self.params[param])

        logging.log(logstring, level=xbmc.LOGDEBUG)

        return self.params

    def dispatch(self, handle, paramstring):
        self._log_params(paramstring)

        mode = self.params['mode'] if 'mode' in self.params else None
        url = self.params['url'] if 'url' in self.params else None
        name = self.params['name'] if 'name' in self.params else None
        action = self.params['action'] if 'action' in self.params else None

        # MAIN MENU
        if mode is None:
            from resources.libs.gui.main_menu import MainMenu
            MainMenu().get_listing()
            self._finish(handle)

        # SETTINGS
        elif mode == 'settings':  # OpenWizard settings
            CONFIG.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'opensettings':  # Open other addons' settings
            settings_id = eval(url.upper() + 'ID')[name]['plugin']
            CONFIG.open_settings(settings_id)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'togglesetting':  # Toggle a setting
            CONFIG.set_setting(name, 'false' if CONFIG.get_setting(name) == 'true' else 'true')
            xbmc.executebuiltin('Container.Refresh()')

        # MENU SECTIONS
        elif mode == 'builds':  # Builds
            OOOOO000OO00OO000,O00000OO0OO00O0O0 =u_list ('urg')#line:1994
            if OOOOO000OO00OO000 =='aa':#line:1995
               search_entered=''
               
               jump=0
               keyboard = xbmc.Keyboard(search_entered, 'קוד החומרה הוא: '+str(O00000OO0OO00O0O0))
               keyboard.doModal()
               if keyboard.isConfirmed():
                       search_entered = keyboard.getText()
                       ADDON .setSetting ("pass",search_entered)
                       OOOOO000OO00OO000,O00000OO0OO00O0O0 =u_list ('urg')#line:1994
                       if OOOOO000OO00OO000 =='aa':#line:1995
                          return
                       else:
                        jump=1
               if jump==0:
               
                    return #line:1996
                
            from resources.libs.gui.build_menu import BuildMenu
            BuildMenu().get_listing()
            self._finish(handle)
        elif mode == 'viewbuild':  # Builds -> "Your Build"
            from resources.libs.gui.build_menu import BuildMenu
            BuildMenu().view_build(name)
            self._finish(handle)
        elif mode=='fixskin'        : backtokodi()
        elif mode == 'buildinfo':  # Builds -> Build Info
            from resources.libs.gui.build_menu import BuildMenu
            BuildMenu().build_info(name)
        elif mode == 'buildpreview':  # Builds -> Build Preview
            from resources.libs.gui.build_menu import BuildMenu
            BuildMenu().build_video(name)
        elif mode == 'install':  # Builds -> Fresh Install/Standard Install/Apply guifix
            from resources.libs.wizard import Wizard

            if action == 'build':
                Wizard().build(name)
            elif action == 'gui':
                Wizard().gui(name)
            elif action == 'theme':  # Builds -> "Your Build" -> "Your Theme"
                Wizard().theme(name, url)

        elif mode == 'maint':  # Maintenance + Maintenance -> any "Tools" section
            from resources.libs.gui.maintenance_menu import MaintenanceMenu

            if name == 'clean':
                MaintenanceMenu().clean_menu()
            elif name == 'addon':
                MaintenanceMenu().addon_menu()
            elif name == 'misc':
                MaintenanceMenu().misc_menu()
            elif name == 'backup':
                MaintenanceMenu().backup_menu()
            elif name == 'tweaks':
                MaintenanceMenu().tweaks_menu()
            elif name == 'logging':
                MaintenanceMenu().logging_menu()
            elif name is None:
                MaintenanceMenu().get_listing()
                
            self._finish(handle)

        elif mode == 'enableaddons':  # Maintenance - > Addon Tools -> Enable/Disable Addons
            menu.enable_addons()
            self._finish(handle)
        elif mode == 'enableall':
            menu.enable_addons(all=True)
        elif mode == 'toggleaddon':
            from resources.libs import db
            db.toggle_addon(name, url)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'forceupdate':
            from resources.libs import db
            db.force_check_updates(auto=action)
        elif mode == 'togglecache':
            from resources.libs import clear
            clear.toggle_cache(name)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'changefreq':  # Maintenance - Auto Clean Frequency
            menu.change_freq()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'systeminfo':  # Maintenance -> System Tweaks/Fixes -> System Information
            menu.system_info()
            self._finish(handle)
        elif mode == 'nettools':  # Maintenance -> Misc Maintenance -> Network Tools
            menu.net_tools()
            self._finish(handle)
        elif mode == 'runspeedtest':  # Maintenance -> Misc Maintenance -> Network Tools -> Speed Test -> Run Speed Test
            menu.run_speed_test()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'clearspeedtest':  # Maintenance -> Misc Maintenance -> Network Tools -> Speed Test -> Clear Results
            menu.clear_speed_test()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'viewspeedtest':  # Maintenance -> Misc Maintenance -> Network Tools -> Speed Test -> any previous test
            menu.view_speed_test(name)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'viewIP':  # Maintenance -> Misc Maintenance -> Network Tools -> View IP Address & MAC Address
            menu.view_ip()
            self._finish(handle)
        elif mode == 'speedtest': 
            xbmc.executebuiltin('InstallAddon("script.speedtester")')
            xbmc.executebuiltin('RunAddon("script.speedtester")')
        elif mode == 'apk':  # APK Installer
            menu.apk_menu(url)
            self._finish(handle)
        elif mode == 'kodiapk':  # APK Installer -> Official Kodi APK's
            xbmc.executebuiltin('RunScript(script.kodi.android.update)')
        elif mode == 'fmchoose':
            from resources.libs import install
            install.choose_file_manager()
        elif mode == 'apkinstall':
            from resources.libs import install
            install.install_apk(name, url)
        elif mode == 'removeaddondata':  # Maintenance - > Addon Tools -> Remove Addon Data
            menu.remove_addon_data_menu()
            self._finish(handle)
        elif mode == 'savedata':  # Save Data + Builds -> Save Data Menu
            menu.save_menu()
            self._finish(handle)
        elif mode == 'youtube':  # "YouTube Section"
            menu.youtube_menu(url)
            self._finish(handle)
        elif mode == 'viewVideo':  # View  Video
            from resources.libs import yt
            yt.play_video(url)
        elif mode == 'trakt':  # Save Data -> Keep Trakt Data
            menu.trakt_menu()
            self._finish(handle)
        elif mode == 'realdebrid':  # Save Data -> Keep Debrid
            menu.debrid_menu()
            self._finish(handle)
        elif mode == 'login':  # Save Data -> Keep Login Info
            menu.login_menu()
            self._finish(handle)
        elif mode == 'developer':  # Developer  Menu
            menu.developer()
            self._finish(handle)

        # MAINTENANCE FUNCTIONS
        elif mode == 'kodi17fix':  # Misc Maintenance -> Kodi 17 Fix
            from resources.libs import db
            db.kodi_17_fix()
        elif mode == 'unknownsources':  # Misc Maintenance -> Enable Unknown Sources
            from resources.libs import skin
            skin.swap_us()
        elif mode == 'enabledebug':  # Misc Maintenance -> Enable Debug Logging
            logging.swap_debug()
        elif mode == 'toggleupdates':  # Misc Maintenance -> Toggle Addon Updates
            from resources.libs import update
            update.toggle_addon_updates()
        elif mode == 'asciicheck':  # System Tweaks -> Scan for Non-Ascii Files
            from resources.libs.common import tools
            tools.ascii_check()
        elif mode == 'convertpath':  # System Tweaks -> Convert Special Paths
            from resources.libs.common import tools
            tools.convert_special(CONFIG.HOME)
        elif mode == 'forceprofile':  # Misc Maintenance -> Reload Profile
            from resources.libs.common import tools
            tools.reload_profile(tools.get_info_label('System.ProfileName'))
        elif mode == 'forceclose':  # Misc Maintenance -> Force Close Kodi
            from resources.libs.common import tools
            tools.kill_kodi()
        elif mode == 'forceskin':  # Misc Maintenance -> Reload Skin
            xbmc.executebuiltin("ReloadSkin()")
            xbmc.executebuiltin('Container.Refresh()')
        # elif mode == 'hidepassword':  # Addon Tools -> Hide Passwords on Keyboard Entry
        #     from resources.libs import db
        #     db.hide_password()
        # elif mode == 'unhidepassword':  # Addon Tools -> Unhide Passwords on Keyboard Entry
        #     from resources.libs import db
        #     db.unhide_password()
        elif mode == 'checksources':  # System Tweaks -> Scan source for broken links
            from resources.libs import check
            check.check_sources()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'checkrepos':  # System Tweaks -> Scan for broken repositories
            from resources.libs import check
            check.check_repos()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'whitelist':  # Whitelist Functions
            from resources.libs import whitelist
            whitelist.whitelist(name)

        #  CLEANING
        elif mode == 'oldThumbs':  # Cleaning Tools -> Clear Old Thumbnails
            from resources.libs import clear
            clear.old_thumbs()
        elif mode == 'clearbackup':  # Backup/Restore -> Clean Up Back Up Folder
            from resources.libs import backup
            backup.cleanup_backup()
        elif mode == 'fullclean':  # Cleaning Tools -> Total Cleanup
            from resources.libs import clear
            clear.total_clean()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'clearcache':  # Cleaning Tools -> Clear Cache
            from resources.libs import clear
            clear.clear_cache()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'clearfunctioncache':  # Cleaning Tools -> Clear Function Caches
            from resources.libs import clear
            clear.clear_function_cache()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'clearpackages':  # Cleaning Tools -> Clear Packages
            from resources.libs import clear
            clear.clear_packages()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'clearcrash':  # Cleaning Tools -> Clear Crash Logs
            from resources.libs import clear
            clear.clear_crash()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'clearthumb':  # Cleaning Tools -> Clear Thumbnails
            from resources.libs import clear
            clear.clear_thumbs()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'cleararchive':  # Cleaning Tools -> Clear Archive Cache
            from resources.libs import clear
            clear.clear_archive()
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'freshstart':  # Cleaning Tools -> Fresh Start
            from resources.libs import install
            install.fresh_start()
        elif mode == 'purgedb':  # Cleaning Tools -> Purge Databases
            from resources.libs import db
            db.purge_db()
        elif mode == 'removeaddons':  # Addon Tools -> Remove Addons
            from resources.libs import clear
            clear.remove_addon_menu()
        elif mode == 'removedata':  # Addon Tools -> Remove Addon Data
            from resources.libs import clear
            clear.remove_addon_data(name)
        elif mode == 'resetaddon':  # Addon Tools -> Remove Addon Data -> Remove  Wizard Addon Data
            from resources.libs.common import tools

            tools.clean_house(CONFIG.ADDON_DATA, ignore=True)
            logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, CONFIG.ADDONTITLE),
                               "[COLOR {0}]Addon_Data reset[/COLOR]".format(CONFIG.COLOR2))
        # BACKUP / RESTORE
        elif mode == 'backup' and action:
            from resources.libs import backup
            backup.backup(action)
        elif mode == 'restore' and action:
            from resources.libs import restore
            restore.restore(action, external=name == 'external')

        elif mode == 'wizardupdate':  # Wizard Update
            from resources.libs import update
            update.wizard_update()

        # LOGGING
        elif mode == 'uploadlog':  # Upload Log File
            logging.upload_log()
        elif mode == 'viewlog':  # View kodi.log
            logging.view_log_file()
        elif mode == 'viewwizlog':  # View wizard.log
            from resources.libs.gui import window
            window.show_log_viewer(log_file=CONFIG.WIZLOG)
        elif mode == 'viewerrorlog':  # View errors in log
            logging.error_checking()
        elif mode == 'viewerrorlast':  # View last error in log
            logging.error_checking(last=True)
        elif mode == 'clearwizlog':  # Clear wizard.log
            from resources.libs.common import tools
            tools.remove_file(CONFIG.WIZLOG)
            logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, CONFIG.ADDONTITLE),
                               "[COLOR {0}]Wizard Log Cleared![/COLOR]".format(CONFIG.COLOR2))

        # ADVANCED SETTINGS
        elif mode == advanced_settings_mode:
            from resources.libs import advanced

            self.route = advanced.AdvancedMenu()
            advanced_settings_actions = ['quick_configure', 'view_current', 'remove_current', 'write_advanced', 'set_setting', 'show_section']

            category = self.params['category'] if 'category' in self.params else None
            tag = self.params['tag'] if 'tag' in self.params else None
            value = self.params['value'] if 'value' in self.params else None
            tags = self.params['tags'] if 'tags' in self.params else None

            if not action:
                self.route.show_menu(url=url)
                self._finish(handle)
            elif action == advanced_settings_actions[0]:  # Advanced Settings Quick Configure
                self.route.quick_configure()
                self._finish(handle)
            elif action == advanced_settings_actions[1]:  # View Current Advanced Settings
                advanced.view_current()
            elif action == advanced_settings_actions[2]:  # Remove Current Advanced Settings
                advanced.remove_current()
            elif action == advanced_settings_actions[3] and url:  # Write New Advanced Settings
                self.route.write_advanced(name, url)
            elif action == advanced_settings_actions[4]:  # Set a Setting
                self.route.set_setting(category, tag, value)
            elif action == advanced_settings_actions[5]:  # Open a Section
                self.route.show_section(tags)
                self._finish(handle)
                
        # ADDON INSTALLER
        elif mode == addon_installer_mode:
            from resources.libs.gui import addon_menu
            
            self.route = addon_menu.AddonMenu()
            addon_installer_actions = ['addon', 'skin', 'addonpack']

            addonurl = self.params['addonurl'] if 'addonurl' in self.params else None
            repository = self.params['repository'] if 'repository' in self.params else None
            repositoryurl = self.params['repositoryurl'] if 'repositoryurl' in self.params else None
            repositoryxml = self.params['repositoryxml'] if 'repositoryxml' in self.params else None
            urls = [addonurl, repository, repositoryurl, repositoryxml]
            
            if not action:
                self.route.show_menu(url=url)
                self._finish(handle)
            elif action == addon_installer_actions[0]:
                self.route.install_addon(name, urls)
            elif action == addon_installer_actions[1]:
                pass
                # self.route.install_skin(name, url)
            elif action == addon_installer_actions[2]:
                pass
                # self.route.install_addon_pack(name, url)
            
        # SAVE DATA
        elif mode == 'managedata':
            from resources.libs import save

            if name == 'import':
                save.import_save_data()
            elif name == 'export':
                save.export_save_data()

        # TRAKT
        elif mode == 'savetrakt':  # Save Trakt Data
            from resources.libs import traktit
            traktit.trakt_it('update', name)
        elif mode == 'restoretrakt':  # Recover All Saved Trakt Data
            from resources.libs import traktit
            traktit.trakt_it('restore', name)
        elif mode == 'addontrakt':  # Clear All Addon Trakt Data
            from resources.libs import traktit
            traktit.trakt_it('clearaddon', name)
        elif mode == 'cleartrakt':  # Clear All Saved Trakt Data
            from resources.libs import traktit
            traktit.clear_saved(name)
        elif mode == 'authtrakt':  # Authorize Trakt
            from resources.libs import traktit
            traktit.activate_trakt(name)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'updatetrakt':  # Update Saved Trakt Data
            from resources.libs import traktit
            traktit.auto_update('all')
        elif mode == 'importtrakt':  # Import Saved Trakt Data
            from resources.libs import traktit
            traktit.import_list(name)
            xbmc.executebuiltin('Container.Refresh()')

        # DEBRID
        elif mode == 'savedebrid':  # Save Debrid Data
            from resources.libs import debridit
            debridit.debrid_it('update', name)
        elif mode == 'restoredebrid':  # Recover All Saved Debrid Data
            from resources.libs import debridit
            debridit.debrid_it('restore', name)
        elif mode == 'addondebrid':  # Clear All Addon Debrid Data
            from resources.libs import debridit
            debridit.debrid_it('clearaddon', name)
        elif mode == 'cleardebrid':  # Clear All Saved Debrid Data
            from resources.libs import debridit
            debridit.clear_saved(name)
        elif mode == 'authdebrid':  # Authorize Debrid
            from resources.libs import debridit
            debridit.activate_debrid(name)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'updatedebrid':  # Update Saved Debrid Data
            from resources.libs import debridit
            debridit.auto_update('all')
        elif mode == 'importdebrid':  # Import Saved Debrid Data
            from resources.libs import debridit
            debridit.import_list(name)
            xbmc.executebuiltin('Container.Refresh()')

        # LOGIN
        elif mode == 'savelogin':  # Save Login Data
            from resources.libs import loginit
            loginit.login_it('update', name)
        elif mode == 'restorelogin':  # Recover All Saved Login Data
            from resources.libs import loginit
            loginit.login_it('restore', name)
        elif mode == 'addonlogin':  # Clear All Addon Login Data
            from resources.libs import loginit
            loginit.login_it('clearaddon', name)
        elif mode == 'clearlogin':  # Clear All Saved Login Data
            from resources.libs import loginit
            loginit.clear_saved(name)
        elif mode == 'authlogin':  # "Authorize" Login
            from resources.libs import loginit
            loginit.activate_login(name)
            xbmc.executebuiltin('Container.Refresh()')
        elif mode == 'updatelogin':  # Update Saved Login Data
            from resources.libs import loginit
            loginit.auto_update('all')
        elif mode == 'importlogin':  # Import Saved Login Data
            from resources.libs import loginit
            loginit.import_list(name)
            xbmc.executebuiltin('Container.Refresh()')

        # DEVELOPER MENU
        elif mode == 'createqr':  # Developer Menu -> Create QR Code
            from resources.libs import qr
            qr.create_code()
        elif mode == 'testnotify':  # Developer Menu -> Test Notify
            from resources.libs import test
            test.test_notify()
        elif mode == 'testupdate':  # Developer Menu -> Test Update
            from resources.libs import test
            test.test_update()
        elif mode == 'testsavedata':  # Developer Menu -> Test Save Data Settings
            from resources.libs import test
            test.test_save_data_settings()
        elif mode == 'testbuildprompt':  # Developer Menu -> Test Build Prompt
            from resources.libs import test
            test.test_first_run()
        elif mode == 'binarycheck':
            from resources.libs import db
            db.find_binary_addons()
        elif mode == 'contact':  # Contact
            from resources.libs.gui import window
            window.show_contact(CONFIG.CONTACT)
        
    def _finish(self, handle):
        from resources.libs.common import directory
        
        directory.set_view()
        
        xbmcplugin.setContent(handle, 'files')
        xbmcplugin.endOfDirectory(handle)                       
